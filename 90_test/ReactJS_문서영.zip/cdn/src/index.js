// import cards from "./card_data";
// import Card from "./card";

// index.html에 출력
const container = document.getElementById("root");
const root = ReactDOM.createRoot(container);
root.render(<App />);


